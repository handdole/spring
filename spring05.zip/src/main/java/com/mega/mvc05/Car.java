package com.mega.mvc05;

public interface Car {
	void run();
	void stop();
}
