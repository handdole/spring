package com.mega.mvc05;

public interface Computer {
	void start();
	void off();
}
