package com.mega.mvc05;

public class ComputerUse {
	public static void main(String[] args) {
		AppleComputer a = new AppleComputer();
		a.start();
		a.off();
	}
}
