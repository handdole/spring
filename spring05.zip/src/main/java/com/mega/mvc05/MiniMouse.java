package com.mega.mvc05;

public class MiniMouse implements Mouse {

	@Override
	public void click() {
		System.out.println("mini���콺 Ŭ����");
	}

}
