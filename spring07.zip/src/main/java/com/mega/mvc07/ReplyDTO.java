package com.mega.mvc07;

public class ReplyDTO {
	private String id , bbsnum , content , writer;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getbbsnum() {
		return bbsnum;
	}

	public void setbbsnum(String bbsnum) {
		this.bbsnum = bbsnum;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}
}
