package com.mega.mvc04;

public interface Phone {
	void call();
	String called(String person);
	void text();
}
