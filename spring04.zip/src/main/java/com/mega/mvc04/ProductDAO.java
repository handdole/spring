package com.mega.mvc04;

public class ProductDAO {

}
